% Load in a file from the directory Edata
S=load('jbClustEnglish_head_0781.mat');

% It seems that S.DIMENSION is the key to the dimensions of S.DATA
disp(S.dimension.descriptor)
disp(S.dimension.axis{1}); % sampled time points
disp(S.dimension.axis{2}); % coordinates measured for each sampled time point and for each articulator
disp(S.dimension.axis{3}); % receiver coil

% Plot xpos (red), ypos (green), and zpos(blue) for TB over all sampled
% time points.
colr='rgb';
for i=1:3
    plot(S.data(:,i,strmatch('TB',{S.dimension.axis{3}})),colr(i)), hold on
end
hold off

% Examining the plot shows that the dimension labeled xpos in
% S.DIMENSION.AXIS{2} undergoes little displacement. I would have thought
% that xpos corresponds to horizontal (anterior-posterior) dimension, ypos 
% corresponds to the vertical (superior-inferior) dimension, and zpos 
% corresponds to the left-right (sinistral-dextral) dimension. Instead, it
% seems that xpos corresponds to the left-right (sinistral-dextral)
% dimension, given how little it receivers move in this dimension relative
% to ypos and zpos. Can you let me know how the coordinate system was
% constructed?
